"""Shared data types for OSINT lookups. Pydantic for serialisation, dataclasses for hot paths."""
from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class QueryKind(StrEnum):
    USERNAME = "username"
    EMAIL = "email"
    PHONE = "phone"
    TELEGRAM = "telegram"
    WHATSAPP = "whatsapp"
    IP = "ip"
    DOMAIN = "domain"
    PASSWORD = "password"   # noqa: S105 — kind identifier, not a password value
    HASH = "hash"           # md5/sha1/sha256 for malware / IOC lookups


class HitStatus(StrEnum):
    FOUND = "found"           # account/profile exists
    NOT_FOUND = "not_found"   # confirmed absent
    UNCERTAIN = "uncertain"   # ambiguous response (often soft block / detection-evading)
    ERROR = "error"           # OUR bug: parse fail, code crash, bad URL
    RATELIMITED = "ratelimited"
    UNAVAILABLE = "unavailable"  # upstream 5xx/521/timeout — service-side, NOT our fault
    NO_DATA = "no_data"       # source healthy, returned empty set (correct but boring)
    SKIPPED = "skipped"       # disabled, missing creds, etc.


class Severity(StrEnum):
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class Hit(BaseModel):
    """A single OSINT finding. One Hit per (module, site/source) pair."""

    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    module: str
    source: str                       # e.g. "github.com", "hibp", "telegram"
    category: str = ""                # e.g. "social", "breach", "messaging"
    status: HitStatus
    title: str = ""
    url: str = ""
    detail: str = ""                  # short human description
    extra: dict[str, Any] = Field(default_factory=dict)
    severity: Severity = Severity.INFO
    found_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    latency_ms: int = 0

    @property
    def is_positive(self) -> bool:
        return self.status == HitStatus.FOUND


class Query(BaseModel):
    """A single user-issued query. Kinds are dispatched to one or more modules."""

    model_config = ConfigDict(extra="ignore")

    kind: QueryKind
    value: str                        # the input string (username, email, phone…)
    note: str = ""
    started_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class QueryResult(BaseModel):
    """Aggregate of all hits for a single query."""

    model_config = ConfigDict(extra="ignore")

    query: Query
    hits: list[Hit] = Field(default_factory=list)
    finished_at: datetime | None = None
    duration_ms: int = 0

    @property
    def positives(self) -> list[Hit]:
        return [h for h in self.hits if h.is_positive]

    @property
    def errors(self) -> list[Hit]:
        return [h for h in self.hits if h.status == HitStatus.ERROR]

    @property
    def total(self) -> int:
        return len(self.hits)

    @property
    def found(self) -> int:
        return len(self.positives)
